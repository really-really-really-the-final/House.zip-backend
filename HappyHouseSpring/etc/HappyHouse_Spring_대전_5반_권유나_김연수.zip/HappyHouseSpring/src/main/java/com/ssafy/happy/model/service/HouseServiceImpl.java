package com.ssafy.happy.model.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happy.dto.House;
import com.ssafy.happy.model.repo.HouseRepo;

@Service
public class HouseServiceImpl implements HouseService {
	
	@Autowired
	public HouseRepo repo;
	
	@Override
	public List<House> selectGugun(String guGun) throws SQLException {
		System.out.println("guGun "+ guGun);
		return repo.selectGugun(guGun);
	}
	
	@Override
	public House select(int no) throws SQLException {
		return repo.select(no);
	}
	@Override
	public List<House> selectDong(String dong) throws SQLException {
		return repo.selectDong(dong);
	}
	@Override
	public List<House> selectApt(String aptName) throws SQLException {
		return repo.selectApt(aptName);
	}

}
