package com.ssafy.happy.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.happy.dto.House;
import com.ssafy.happy.dto.Notice;
import com.ssafy.happy.dto.User;
import com.ssafy.happy.model.service.HouseService;
import com.ssafy.happy.model.service.NoticeService;
import com.ssafy.happy.model.service.StoreService;
import com.ssafy.happy.model.service.UserService;

@Controller
public class MainController {
	@Autowired
	UserService usvc;
	@Autowired
	HouseService hsvc;
	@Autowired
	NoticeService nsvc;
	@Autowired
	StoreService ssvc;

	@GetMapping({ "/", "/index" })
	public String index(HttpSession session) {
		User user = (User) session.getAttribute("loginUser");
		return "index";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@PostMapping("/loginc")
	public String loginc(User user, HttpSession session, Model m) throws SQLException {
		User selected = usvc.select(user.getId());
		if (selected != null && user.getPassword().equals(selected.getPassword())) {
			session.setAttribute("loginUser", selected);
			return "redirect:/";
		} else {
			m.addAttribute("msg", "로그인 실패");
			return "index";
		}
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	@PostMapping("/list")
	public String list(String gugun, Model m) throws SQLException {
		List<House> houses = hsvc.selectGugun(gugun);
		m.addAttribute("houses", houses);
		return "index";
	}
	
	@GetMapping("/register")
	public String register() {
		return "sign";
	}

	@PostMapping("/regist")
	public String regist(User user, Model m) throws SQLException {
		usvc.insert(user);
		m.addAttribute("msg", "회원가입 성공");
		return "index";
	}

	@GetMapping("/findpwd")
	public String findpwd() {
		return "findpwd";
	}

	@PostMapping("/findpwdc")
	public String findpwdc(User user, Model m, HttpSession session) throws SQLException {
		User selected = usvc.select(user.getId());
		if (selected != null && user.getName().equals(user.getName()) && user.getTel().equals(user.getTel())) {
			selected.setPassword("1234");
			usvc.update(selected);
			m.addAttribute("msg", "비밀번호가 1234로 초기화 되었습니다.");
			return "index";
		} else {
			m.addAttribute("msg", "회원인증 실패");
			return "index";
		}
	}

	@GetMapping("/mypage")
	public String mypage(Model m, HttpSession session) throws SQLException {
		User user = (User) session.getAttribute("loginUser");
		m.addAttribute("user", user);
		return "mypage";
	}

	@GetMapping("/rmuser")
	public String rmuser(Model m, HttpSession session) throws SQLException {
		User user = (User) session.getAttribute("loginUser");
		usvc.delete(user.getId());
		return "redirect:/logout";
	}

	@PostMapping("/modify")
	public String modify(User user, Model m, HttpSession session) throws SQLException {
		usvc.update(user);
		session.setAttribute("loginUser", user);
		m.addAttribute("msg", "정보를 수정했습니다.");
		return "index";
	}

	@GetMapping("/notice")
	public String notice(Model m, HttpSession session) throws SQLException {
		List<Notice> notices = nsvc.selectAll();
		m.addAttribute("notices", notices);
		if (session != null)
			m.addAttribute("ism", ((User) session.getAttribute("loginUser")).isManager());
		return "notice";
	}

	@GetMapping("/noticedetail")
	public String noticedetail(int no, Model m, HttpSession session) throws SQLException {
		Notice notice = nsvc.select(no);
		m.addAttribute("notice", notice);
		if (session != null)
			m.addAttribute("ism", ((User) session.getAttribute("loginUser")).isManager());
		return "noticedetail";
	}

	@GetMapping("/wrnotice")
	public String wrnotice() throws SQLException {
		return "noticewrite";
	}

	@GetMapping("/monotice")
	public String monotice(String wrid, int no, HttpSession session, Model m) throws SQLException {

		User user = (User) session.getAttribute("loginUser");
		if (wrid.equals(user.getId())) {
			Notice notice = nsvc.select(no);
			m.addAttribute("notice", notice);
			return "noticemodify";
		} else {
			m.addAttribute("msg", "본인이 작성한 글이 아닙니다.");
			return "index";
		}
	}

	@GetMapping("/rmnotice")
	public String rmnotice(String wrid, int no, HttpSession session, Model m) throws SQLException {
		User user = (User) session.getAttribute("loginUser");
		if (wrid.equals(user.getId())) {
			nsvc.delete(no);
			m.addAttribute("msg", "삭제했습니다.");
		} else {
			m.addAttribute("msg", "본인이 작성한 글이 아닙니다.");
		}
		return "index";
	}

	@PostMapping("/savenotice")
	public String savenotice(Notice notice, HttpSession session, Model m) throws SQLException {

		User user = (User) session.getAttribute("loginUser");
		notice.setUserId(user.getId());
		nsvc.insert(notice);
		m.addAttribute("msg", "공지등록 성공");
		return "index";

	}

	@PostMapping("/upnotice")
	public String upnotice(Notice notice, int no, HttpSession session, Model m) throws SQLException {

		User user = (User) session.getAttribute("loginUser");
		notice.setUserId(user.getId());
		notice.setNo(no);
		nsvc.update(notice);
		m.addAttribute("msg", "공지수정 성공");
		return "index";
	}
	
	@GetMapping("/dongSearch")
	public String dongSearch() throws SQLException {
		return "dongCheck";
	}
	
	@GetMapping("/aptSearch")
	public String aptSearch() throws SQLException {
		return "aptCheck";
	}
	
	@PostMapping("/dongList")
	public String dongList(String dong,Model m) throws SQLException {
		List<House> donglist = hsvc.selectDong(dong);
		m.addAttribute("donglist", donglist);
		return "dongCheck";
	}
	
	@PostMapping("/aptList")
	public String aptList(String aptName,Model m) throws SQLException {
		List<House> aptlist = hsvc.selectApt(aptName);
		m.addAttribute("aptlist", aptlist);
		return "aptCheck";
	}
	
	@GetMapping("/view")
	public String view(int no, Model m) throws SQLException {
		House house = hsvc.select(no);
		m.addAttribute("house", house);
		return "detailCheck";
	}
	
	@GetMapping("/intro")
	public String intro(Model m) throws SQLException {
		return "intro";
	}
	
	

}