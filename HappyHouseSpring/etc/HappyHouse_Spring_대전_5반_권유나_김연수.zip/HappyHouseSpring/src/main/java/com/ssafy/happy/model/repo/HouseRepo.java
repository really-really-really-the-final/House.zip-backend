package com.ssafy.happy.model.repo;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happy.dto.House;

public interface HouseRepo {
	
	House select(int no) throws SQLException;
	List<House> selectGugun(String guGun) throws SQLException;
	List<House> selectDong(String dong) throws SQLException;
	List<House> selectApt(String aptName) throws SQLException;
}
